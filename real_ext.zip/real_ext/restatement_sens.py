"""Sensitivity of the restatement result to the label rule. Reads restatement_obs.csv written by restatement_eval.py."""
import os, json, numpy as np, pandas as pd
from scipy.stats import rankdata
HERE = os.path.dirname(os.path.abspath(__file__))
O = pd.read_csv(os.path.join(HERE, 'restatement_obs.csv'))
UNIT = {'Tata Steel (standalone)': 1e6, 'ITC': 1000.0, 'Grasim': 1e4, 'NTPC': 1e4}
SC = [('Raw year-on-year change (size)', 'abs_y'), ('Peer-centred change (size)', 'abs_yr'), ('Peer-centred level (size)', 'abs_lr'),
      ('Peer z-score (change and level)', 'peer_z'), ('Raw emissions level', 'lvl')]
def flag(a, b, u, rel):
    if np.isnan(a) or np.isnan(b): return np.nan
    return float(abs(b - a) > rel * abs(a) and abs(b - a) > 1.5 * u)
def auc(s, y):
    r = rankdata(s); n1 = y.sum(); n0 = len(y) - n1
    return (r[y == 1].sum() - n1 * (n1 + 1) / 2) / (n1 * n0)
def labels(rule, rel):
    out = []
    for _, r in O.iterrows():
        u = UNIT.get(r.company, 1.0)
        f1 = flag(r.s1_first, r.s1_next, u, rel); f2 = flag(r.s2_first, r.s2_next, u, rel)
        ft = flag(r.s1_first + r.s2_first, r.s1_next + r.s2_next, u, rel)
        v = {'either': np.nanmax([f1, f2]) if not (np.isnan(f1) and np.isnan(f2)) else np.nan, 'S1 only': f1, 'S2 only': f2, 'total': ft}[rule]
        out.append(v)
    return np.array(out)
rng = np.random.default_rng(1); rows = []
for rule, rel in [('either', 0.01), ('either', 0.005), ('either', 0.02), ('either', 0.05), ('S1 only', 0.01), ('S2 only', 0.01), ('total', 0.01)]:
    L = labels(rule, rel); ok = ~np.isnan(L); npos = int(L[ok].sum())
    row = dict(rule=rule, threshold='%.1f%%' % (100 * rel), n=int(ok.sum()), positives=npos)
    best = None
    for name, col in SC:
        m = ok & O[col].notna().values; y = L[m].astype(int); s = O.loc[m, col].values
        if y.sum() < 2: continue
        a = auc(s, y); perm = [auc(s, rng.permutation(y)) for _ in range(5000)]
        p = (1 + sum(x >= a - 1e-12 for x in perm)) / 5001
        row[name] = (round(float(a), 3), round(float(p), 3))
        if best is None or a > best[1]: best = (name, a, p)
    row['best'] = None if best is None else (best[0], round(float(best[1]), 3), round(float(best[2]), 3))
    rows.append(row); print(row)
json.dump(rows, open(os.path.join(HERE, 'res_restatement_sens.json'), 'w'), indent=1, default=str)
