"""Restatement label test (Section 8.6 of the paper).
Unit: a company-year observation. The filing for year t gives the features (level, year-on-year change of Scope 1+2).
The label is 1 if the NEXT filing prints a different value for year t than the first filing did.
Rule fixed before scoring: a scope value counts as restated if it differs by more than 1% of the first-filing value AND by
more than 1.5 printed units (so that rounding in the printed table cannot create the difference); a pair is positive if
Scope 1 or Scope 2 is restated.  Reads hand-read values from data/filings_*.py and (for peer references) the 55-company panel."""
import glob, importlib.util, json, os, sys
import numpy as np, pandas as pd
from scipy.stats import rankdata

HERE = os.path.dirname(os.path.abspath(__file__))
ROWS = []
for f in sorted(glob.glob(os.path.join(HERE, 'data', 'filings_*.py'))):
    spec = importlib.util.spec_from_file_location('m', f); m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
    ROWS += m.ROWS
UNIT = {'Tata Steel (standalone)': 1e6, 'ITC': 1000.0, 'Grasim': 1e4, 'NTPC': 1e4}   # printed precision in tCO2e (others print to 1 t or finer)
cols = ['company', 'macro', 'fy', 'file', 'page', 's1', 's2', 's1p', 's2p', 'mult', 'note']
D = pd.DataFrame([r[:11] for r in ROWS], columns=cols)

def restated(a, b, unit):
    if a is None or b is None or np.isnan(a) or np.isnan(b): return np.nan
    return float(abs(b - a) > 0.01 * abs(a) and abs(b - a) > 1.5 * unit)

obs = []
for _, r in D.iterrows():
    nxt = D[(D.company == r.company) & (D.fy == r.fy + 1)]
    if nxt.empty: continue
    n = nxt.iloc[0]; u = UNIT.get(r.company, 1.0)   # all comparisons in tCO2e, each row converted with its own multiplier
    sc = lambda v, m: np.nan if v is None else v * m
    r1 = restated(sc(r.s1, r.mult), sc(n.s1p, n.mult), u); r2 = restated(sc(r.s2, r.mult), sc(n.s2p, n.mult), u)
    tot = (r.s1 + r.s2) * r.mult
    tp = (r.s1p + r.s2p) * r.mult if (r.s1p is not None and r.s2p is not None) else np.nan
    y = np.log(tot / tp) if tp == tp and tp > 0 else np.nan
    pos = float(any(v == 1.0 for v in (r1, r2)))
    obs.append(dict(company=r.company, macro=r.macro, fy=r.fy, label=pos, s1_restated=r1, s2_restated=r2, tot=tot, y=y, lvl=np.log10(tot),
                    s1_first=r.s1 * r.mult, s1_next=n.s1p * n.mult if n.s1p is not None else np.nan,
                    s2_first=r.s2 * r.mult, s2_next=n.s2p * n.mult if n.s2p is not None else np.nan,
                    file_first=r.file, page_first=r.page, file_next=n.file, page_next=n.page, note_next=n.note))
O = pd.DataFrame(obs)
for c, k in (('s1', 's1'), ('s2', 's2')):
    O['%s_pct' % c] = 100 * (O['%s_next' % c] - O['%s_first' % c]) / O['%s_first' % c]

# peers: other companies of the same macro-sector, pooled over years; the 55-company panel adds companies not in this set
PAN = pd.read_csv(os.path.join(HERE, '..', 'real_ext', 'extended_panel_scored.csv')) if os.path.exists(os.path.join(HERE, '..', 'real_ext', 'extended_panel_scored.csv')) else None
ALIAS = {'Adani Ports': 'Adani Ports and SEZ Ltd.', 'Britannia': 'Britannia Industries Ltd.', 'Hindustan Unilever': 'Hindustan Unilever Ltd.', 'Power Grid': 'Power Grid Corporation of India Ltd.', 'TCS': 'TCS Ltd.', 'UltraTech Cement': 'UltraTech Cement Ltd.', 'ICICI Bank': 'ICICI Bank Ltd.', 'Hindustan Zinc': 'Hindustan Zinc Ltd.', 'NTPC': 'NTPC Ltd.', 'Bandhan Bank': 'Bandhan Bank Ltd.', 'ITC': 'ITC Ltd.', 'JSW Steel': 'JSW Steel Ltd.', 'Tata Steel (standalone)': 'Tata Steel Ltd.', 'Vedanta': 'Vedanta Ltd.', 'Coal India': 'Coal India Ltd.', 'Reliance Industries': 'Reliance Industries Ltd.'}
peer_rows = O[['company', 'macro', 'y', 'lvl']].copy()
if PAN is not None:
    have = set(ALIAS.get(c, c) for c in O.company)
    extra = PAN[~PAN.company.isin(have)][['company', 'macro', 'y', 'lvl']]
    peer_rows = pd.concat([peer_rows, extra], ignore_index=True)

def peer_center(col):
    out = []
    for _, r in O.iterrows():
        p = peer_rows[(peer_rows.macro == r.macro) & (peer_rows.company != r.company)].dropna(subset=[col])
        p = p.groupby('company')[col].mean()                       # one value per peer company
        out.append(r[col] - p.mean() if len(p) >= 3 and r[col] == r[col] else np.nan)
    return np.array(out)
O['yr'] = peer_center('y'); O['lr'] = peer_center('lvl')
sdy, sdl = O.yr.std(), O.lr.std()
O['peer_z'] = np.sqrt((O.yr / sdy) ** 2 + (O.lr / sdl) ** 2)
O['abs_y'] = O.y.abs(); O['abs_yr'] = O.yr.abs(); O['abs_lr'] = O.lr.abs()

def auc(s, y):
    r = rankdata(s); n1 = y.sum(); n0 = len(y) - n1
    return (r[y == 1].sum() - n1 * (n1 + 1) / 2) / (n1 * n0)
SC = [('Raw year-on-year change (size)', 'abs_y'), ('Peer-centred change (size)', 'abs_yr'), ('Peer-centred level (size)', 'abs_lr'),
      ('Peer z-score (change and level)', 'peer_z'), ('Raw emissions level', 'lvl')]
rng = np.random.default_rng(0); res = {}
for name, col in SC:
    d = O.dropna(subset=[col]); y = d.label.values.astype(int); s = d[col].values
    if y.sum() < 2 or y.sum() > len(y) - 2: continue
    a = auc(s, y)
    perm = [auc(s, rng.permutation(y)) for _ in range(20000)]
    p = (1 + sum(x >= a - 1e-12 for x in perm)) / (1 + len(perm))
    comp = d.company.values; uc = np.unique(comp); bs = []
    while len(bs) < 4000:                                              # cluster bootstrap: resample companies
        pick = rng.choice(uc, len(uc)); idx = np.concatenate([np.where(comp == c)[0] for c in pick]); yy = y[idx]
        if 0 < yy.sum() < len(yy): bs.append(auc(s[idx], yy))
    lo, hi = np.percentile(bs, [2.5, 97.5])
    res[name] = dict(auc=float(a), lo=float(lo), hi=float(hi), p=float(p), n=int(len(d)), positives=int(y.sum()), companies=int(len(uc)))
    print('%-34s AUC %.3f [%.2f, %.2f]  p=%.3f  n=%d pos=%d' % (name, a, lo, hi, p, len(d), y.sum()))
O.to_csv(os.path.join(HERE, 'restatement_obs.csv'), index=False)
json.dump(res, open(os.path.join(HERE, 'res_restatement.json'), 'w'), indent=1)
print('\nobservations', len(O), '| companies', O.company.nunique(), '| positives', int(O.label.sum()))
print(O[O.label == 1][['company', 'fy', 's1_pct', 's2_pct', 'y']].round(3).to_string(index=False))
