import glob, re, importlib.util, os
def fmts(v):
    out=set()
    if v is None: return out
    for dec in (0,1,2,3):
        x=round(v,dec) if dec else round(v)
        if abs(x-v)>1e-9 and dec==0: pass
        s=('%.*f'%(dec,v)); 
        ip,_,fp=s.partition('.')
        w=format(int(ip),','); 
        r=ip[::-1]; ind=r[:3]; r=r[3:]
        while r: ind+=','+r[:2]; r=r[2:]
        ind=ind[::-1]
        for base in (w,ind,ip):
            out.add(base+('.'+fp if fp else ''))
            if fp: out.add(base+('.'+fp.rstrip('0') if fp.rstrip('0') else ''))
    return out
bad=0; n=0
for f in sorted(glob.glob('data/filings_*.py')):
    spec=importlib.util.spec_from_file_location('m',f); m=importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
    for r in m.ROWS:
        co,mac,fy,pat,pg,s1,s2,s1p,s2p,mult,note=r
        cand=[x for x in glob.glob("txt/*%s*.txt"%pat.replace(" (1)",""))]
        if not cand: print('NOFILE',co,fy,pat); bad+=1; continue
        txt=open(cand[0],encoding='utf-8',errors='ignore').read().split('\f')[pg-1]
        t=re.sub(r'\s+',' ',txt)
        for name,v in (('s1',s1),('s2',s2),('s1p',s1p),('s2p',s2p)):
            if v is None: continue
            n+=1
            ok=any(re.search(r'(?<![\d,.])'+re.escape(x)+r'(?![\d])',t) for x in fmts(v))
            if not ok:
                # scaled printing (Mt, kt)
                for sc in (1e3,1e6):
                    if any(re.search(r'(?<![\d,.])'+re.escape(x)+r'(?![\d])',t) for x in fmts(v/sc)) : ok=True
            if not ok: print('MISSING',co,fy,name,v,'page',pg,cand[0][4:30]); bad+=1
print('checked',n,'values; problems',bad)
