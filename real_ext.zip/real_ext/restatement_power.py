"""How strong a signal could the restatement label set detect? Simulation with normally distributed scores:
positives are shifted by d standard deviations, true ROC-AUC = Phi(d / sqrt 2). Test: one-sided 5% permutation-style cut-off on the AUC."""
import json, os, numpy as np
from scipy.stats import rankdata, norm
HERE = os.path.dirname(os.path.abspath(__file__))
def auc(p, n):
    r = rankdata(np.r_[p, n]); return (r[:len(p)].sum() - len(p) * (len(p) + 1) / 2) / (len(p) * len(n))
import pandas as pd
_O = pd.read_csv(os.path.join(HERE, 'restatement_obs.csv')); NPOS = int(_O.label.sum()); NNEG = len(_O) - NPOS   # observed design
rng = np.random.default_rng(0)
def power(npos, nneg, d, reps=3000):
    null = np.array([auc(rng.normal(size=npos), rng.normal(size=nneg)) for _ in range(10000)]); crit = np.quantile(null, 0.95)
    a = np.array([auc(rng.normal(d, 1, npos), rng.normal(size=nneg)) for _ in range(reps)]); return float(crit), float((a > crit).mean())
out = {'design': {'positives': NPOS, 'negatives': NNEG}, 'power': []}
for d in (0.5, 0.8, 1.0, 1.2, 1.5):
    crit, pw = power(NPOS, NNEG, d); out['power'].append(dict(d=d, true_auc=round(float(norm.cdf(d / np.sqrt(2))), 3), power=round(pw, 2), crit_auc=round(crit, 3)))
need = []
for target in (0.65, 0.70):
    d = np.sqrt(2) * norm.ppf(target)
    for npos in range(10, 130, 5):
        nneg = int(round(npos * NNEG / NPOS))                      # same prevalence as observed (observed share)
        crit, pw = power(npos, nneg, d, reps=1500)
        if pw >= 0.8: need.append(dict(true_auc=target, positives=npos, negatives=nneg, pairs=npos + nneg, power=round(pw, 2))); break
out['needed_for_80pct_power'] = need
json.dump(out, open(os.path.join(HERE, 'res_restatement_power.json'), 'w'), indent=1); print(json.dumps(out, indent=1))
