"""Section 8.6: how well do peer-based scores separate companies with a disclosed comparability break (label 1)
from the rest (label 0)? Reads dcb_eval_set.csv (19 scored companies), writes res_dcb.json.
AUC by ranks; 95% percentile bootstrap (4,000 resamples of companies); one-sided exact permutation p-value over all
C(19,4) = 3,876 ways of choosing which 4 companies are positive."""
import itertools, json
import numpy as np, pandas as pd
from scipy.stats import rankdata

d = pd.read_csv('dcb_eval_set.csv'); y = d.dcb.values.astype(int)
def auc(s, y):
    r = rankdata(s); n1 = y.sum(); n0 = len(y) - n1
    return (r[y == 1].sum() - n1 * (n1 + 1) / 2) / (n1 * n0)
SC = [('Raw year-on-year change (size)', 'abs_y'), ('Peer-centred change (size)', 'abs_yr'),
      ('Peer-centred level (size)', 'abs_lr'), ('Peer z-score (change and level)', 'peer_z'),
      ('Raw emissions level', 'lvl')]
rng = np.random.default_rng(0); out = {}
for name, col in SC:
    s = d[col].values; a = auc(s, y); cnt = tot = 0
    for pos in itertools.combinations(range(len(y)), int(y.sum())):
        yy = np.zeros(len(y), int); yy[list(pos)] = 1; tot += 1; cnt += auc(s, yy) >= a - 1e-12
    bs = []
    while len(bs) < 4000:
        i = rng.integers(0, len(y), len(y))
        if 0 < y[i].sum() < len(y): bs.append(auc(s[i], y[i]))
    lo, hi = np.percentile(bs, [2.5, 97.5])
    out[name] = dict(auc=float(a), lo=float(lo), hi=float(hi), p=cnt / tot, n=len(y), positives=int(y.sum()), assignments=tot)
    print('%-34s AUC %.3f [%.2f, %.2f]  p = %.3f' % (name, a, lo, hi, cnt / tot))
json.dump(out, open('res_dcb.json', 'w'), indent=1)
