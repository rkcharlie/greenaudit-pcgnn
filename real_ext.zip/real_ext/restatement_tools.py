"""Tools for building independent real labels from BRSR filings (used for Section 8.6-8.7 of the paper).

Usage
  python restatement_tools.py notes   <folder_with_pdfs> notes.csv
      Finds the Scope 1/Scope 2 table page in each PDF and lists every line on that page, and every
      emissions-related line elsewhere, that mentions a restatement, boundary, method or scope change.
      A person must read each hit; the script only finds candidates and never assigns a label.
  python restatement_tools.py compare earlier.pdf later.pdf
      Prints Scope 1 and Scope 2 as printed in the earlier filing (current-year column) and the
      prior-year column of the later filing, with the relative difference. Needs pdftotext.
Both commands read printed values only; nothing is estimated.
"""
import csv, glob, os, re, subprocess, sys

KW = re.compile(r'restat|re-stat|recalculat|re-calculat|rebaselin|re-baselin|boundary|methodolog|merger|amalgamat|demerg|'
                r'acquisition|acquired|not comparable|revised|change in|changes in|only (?:includes|covers)|includes only|'
                r'excludes?\b|exclud|reclassif|accounted in', re.I)
EM = re.compile(r'scope|ghg|emission|carbon', re.I)
NUM = re.compile(r'(?<![\w.])(\d{1,3}(?:,\d{2,3})+(?:\.\d+)?|\d+(?:\.\d+)?)(?![\w])')


def pages_of(pdf):
    txt = subprocess.run(['pdftotext', '-layout', pdf, '-'], capture_output=True, text=True).stdout
    return txt.split('\f')


def ghg_page(pages):
    for i, p in enumerate(pages):
        if re.search(r'Total\s+Scope\s*1', p, re.I):
            return i
    return None


def notes(folder, out):
    rows = []
    for pdf in sorted(glob.glob(os.path.join(folder, '*.pdf'))):
        pages = pages_of(pdf)
        g = ghg_page(pages)
        rows.append([os.path.basename(pdf), g + 1 if g is not None else '', 'ghg-table-page', '', ''])
        for i, p in enumerate(pages):
            for line in p.split('\n'):
                s = re.sub(r'\s+', ' ', line.strip())
                if len(s) > 25 and KW.search(s) and EM.search(s):
                    where = 'ghg-table-page' if i == g else 'elsewhere'
                    rows.append([os.path.basename(pdf), i + 1, where, 'hit', s[:300]])
    with open(out, 'w', newline='', encoding='utf-8') as f:
        csv.writer(f).writerow(['file', 'page', 'where', 'kind', 'text'])
        csv.writer(f).writerows(rows)
    print('wrote', out, len(rows), 'rows')


def scope_row(pages, label):
    g = ghg_page(pages)
    if g is None:
        return None
    lines = pages[g].split('\n')
    for j, l in enumerate(lines):
        if re.search(r'Total\s+Scope\s*%s\b' % label, l, re.I) and 'intensity' not in l.lower():
            nums = []
            for k in range(j, min(j + 4, len(lines))):
                nums += [float(n.replace(',', '')) for n in NUM.findall(lines[k]) if not re.fullmatch(r'[12]|20\d\d', n)]
                if len(nums) >= 2:
                    break
            return g + 1, nums[:2]
    return None


def compare(a, b):
    pa, pb = pages_of(a), pages_of(b)
    for lab in ('1', '2'):
        ra, rb = scope_row(pa, lab), scope_row(pb, lab)
        if not ra or not rb or len(ra[1]) < 2 or len(rb[1]) < 2:
            print('Scope', lab, ': could not read both tables; check by hand'); continue
        cur_a, prior_b = ra[1][0], rb[1][1]
        diff = (prior_b - cur_a) / cur_a * 100 if cur_a else float('nan')
        print('Scope %s: earlier filing p.%d current-year %.2f | later filing p.%d prior-year %.2f | difference %+.2f%%' % (lab, ra[0], cur_a, rb[0], prior_b, diff))
    print('Check units and Indian digit grouping by eye before relying on a difference.')


if __name__ == '__main__':
    if len(sys.argv) >= 4 and sys.argv[1] == 'notes':
        notes(sys.argv[2], sys.argv[3])
    elif len(sys.argv) >= 4 and sys.argv[1] == 'compare':
        compare(sys.argv[2], sys.argv[3])
    else:
        print(__doc__)
