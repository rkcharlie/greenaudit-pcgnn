import pandas as pd, numpy as np, json
from scipy import stats
old = pd.read_csv('../modeling_dataset.csv'); lab = pd.read_csv('../company_weak_labels.csv')
oc = old.groupby('company').agg(sector=('sector','first'), s=('scope12_tco2e','mean'), p=('scope12_prior','mean')).reset_index().merge(lab, on='company')
mapping = {'IT/Technology':'Technology & Telecom','Telecommunications':'Technology & Telecom','Pharmaceuticals':'Healthcare & Pharma',
 'Financial Services/Banking':'Financials','Financial Services/Housing Finance':'Financials','FMCG (Food)':'Consumer','FMCG':'Consumer','FMCG (Diversified)':'Consumer',
 'Agrochemicals':'Materials','Steel/Metals':'Materials','Cement/Materials':'Materials','Metals & Mining':'Materials','Manufacturing/Packaging':'Materials',
 'Automobiles':'Automobiles','Energy/Power':'Energy & Utilities','Energy/Power (Mining)':'Energy & Utilities','Energy/Power (Transmission)':'Energy & Utilities',
 'Energy/Oil & Gas (Refining/Marketing)':'Energy & Utilities','Energy/Oil & Gas (City Gas Distribution)':'Energy & Utilities','Energy/Oil & Gas (Refining/Petrochemicals)':'Energy & Utilities',
 'Infrastructure/Ports & Logistics':'Industrials & Logistics','Industrials/Electrical Equipment':'Industrials & Logistics','Manufacturing/Industrials':'Industrials & Logistics'}
oc['macro'] = oc.sector.map(mapping)
assert oc.macro.notna().all(), oc[oc.macro.isna()]
oc['tot_cur'] = oc.s; oc['tot_prev'] = oc.p; oc['origin'] = 'original 38'
# L&T FY2023-24 from the PAM_ file (page 36): Scope1 635,646 / 693,115 ; Scope2 349,682 / 273,719
i = oc.company == 'L&T Ltd.'; oc.loc[i, 'tot_cur'] = 635646 + 349682; oc.loc[i, 'tot_prev'] = 693115 + 273719
oc.loc[i, 'origin'] = 'original 38 (FY23-24 added)'
nc = pd.read_csv('new_companies.csv')
nc['tot_cur'] = nc.s1_cur + nc.s2_cur
nc['tot_prev'] = np.where(nc.s2_prev.isna() | nc.s1_prev.isna(), np.nan, nc.s1_prev + nc.s2_prev)
nc['macro'] = nc.macro_sector; nc['origin'] = 'new'; nc['weak_label'] = np.nan
cols = ['company', 'macro', 'tot_cur', 'tot_prev', 'weak_label', 'origin']
P = pd.concat([oc[cols], nc[cols]], ignore_index=True)
P['lvl'] = np.log10(P.tot_cur.where(P.tot_cur > 0)); P['y'] = np.log(P.tot_cur / P.tot_prev)
P.to_csv('extended_panel.csv', index=False)
print('companies', len(P), '| with level', int(P.lvl.notna().sum()), '| with YoY', int(P.y.notna().sum()))
print(P.groupby('macro').agg(n=('company', 'count'), n_yoy=('y', 'count')).to_string())
g = P.dropna(subset=['y'])
# variance decomposition of YoY log change across macro-sector groups
grp = g.groupby('macro').y
n_g = grp.count(); m_g = grp.mean(); N = len(g)
sst = ((g.y - g.y.mean()) ** 2).sum(); ssw = grp.apply(lambda s: ((s - s.mean()) ** 2).sum()).sum(); ssb = sst - ssw
k = g.macro.nunique(); F = (ssb / (k - 1)) / (ssw / (N - k)); pF = 1 - stats.f.cdf(F, k - 1, N - k)
s_within = np.sqrt(ssw / (N - k)); n0 = (N - (n_g ** 2).sum() / N) / (k - 1)
s_between2 = max(0, (ssb / (k - 1) - ssw / (N - k)) / n0)
mad = lambda x: 1.4826 * np.median(np.abs(x - np.median(x)))
print('\nYoY log change: overall sd %.3f, robust sd %.3f' % (g.y.std(), mad(g.y)))
print('between-sector variance share (ANOVA): %.1f%% (F=%.2f, p=%.2f);  sigma_between = %.3f, sigma_within = %.3f' % (100 * ssb / sst, F, pF, np.sqrt(s_between2), s_within))
# robust within (MAD of residuals after removing group median)
res = g.y - g.groupby('macro').y.transform('median'); print('robust within-sector sd (MAD): %.3f' % mad(res))
# peer-centred scores
def peer_resid(df, col):
    out = pd.Series(np.nan, index=df.index)
    for m, d in df.groupby('macro'):
        d = d.dropna(subset=[col])
        if len(d) < 3: continue
        tot = d[col].sum()
        out.loc[d.index] = d[col] - (tot - d[col]) / (len(d) - 1)
    return out
P['yr'] = peer_resid(P, 'y'); P['lr'] = peer_resid(P, 'lvl')
sdy = P.yr.std(); sdl = P.lr.std()
P['peer_z'] = np.sqrt((P.yr / sdy) ** 2 + (P.lr / sdl) ** 2)
print('\nTop 12 by peer z-score (candidates for MANUAL audit only - not findings):')
top = P.sort_values('peer_z', ascending=False).head(12)[['company', 'macro', 'tot_cur', 'tot_prev', 'y', 'yr', 'lr', 'peer_z']]
print(top.round(3).to_string(index=False))
P.to_csv('extended_panel_scored.csv', index=False)
# check against the heuristic weak label on the originals, now with real peers
o = P[P.origin.str.startswith('original') & P.weak_label.notna()].copy()
o['yb'] = (o.weak_label == 'NEGATIVE').astype(int)
from sklearn.metrics import roc_auc_score
for nm, col in (('raw YoY change', 'y'), ('peer-centred YoY change', 'yr'), ('peer z (YoY + level)', 'peer_z')):
    d = o.dropna(subset=[col]); 
    print('%-26s AUC vs heuristic label: %.3f  (n=%d, %d flagged)' % (nm, roc_auc_score(d.yb, d[col]), len(d), d.yb.sum()))
json.dump(dict(n=len(P), n_yoy=int(P.y.notna().sum()), F=F, pF=pF, between_share=float(ssb / sst), sd_between=float(np.sqrt(s_between2)), sd_within=float(s_within), overall_sd=float(g.y.std())), open('res_ext.json', 'w'))
