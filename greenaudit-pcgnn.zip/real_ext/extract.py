import subprocess, re, glob, os, json, sys
base = '/mnt/user-data/uploads/2-Objective-framework_paper_Sended_For_Publication_Information_Science/Data_souces'
files = sorted(glob.glob(base + '/esg_data_2/*.pdf') + glob.glob(base + '/esg_data_3/*.pdf'))
num = r'(?<![\d.,])(\d{1,3}(?:,\d{2,3})*(?:\.\d+)?|\d+(?:\.\d+)?)(?![\d])'
out = {}
for f in files:
    nm = os.path.basename(f)
    txt = subprocess.run(['pdftotext', '-layout', f, '-'], capture_output=True, text=True).stdout
    pages = txt.split('\f')
    hits = []
    for pi, pg in enumerate(pages, 1):
        lines = pg.split('\n')
        for li, ln in enumerate(lines):
            if re.search(r'Total\s+Scope\s*[12]\b', ln, re.I) or re.search(r'Scope\s*[12]\s+emissions', ln, re.I):
                ctx = ' '.join(l.strip() for l in lines[li:li + 4])
                hits.append((pi, ln.strip()[:60], ctx[:330]))
    out[nm] = dict(npages=len(pages), hits=hits[:8])
json.dump(out, open('hits.json', 'w'), indent=1)
for nm, v in out.items():
    print('=====', nm, 'pages', v['npages'], 'hits', len(v['hits']))
    for h in v['hits'][:4]:
        print('  p%d | %s' % (h[0], h[2][:300]))
